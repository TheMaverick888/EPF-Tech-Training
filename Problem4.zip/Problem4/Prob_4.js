let userInput;
        function storeInput(value){
            while (value < 2001) {
                userInput = value;
            }
            
            
        }
        
        function largestPalindrome() {
            let product;
            let prodToStr;
            let largestPal = 0;
        

            for (let x = 1; x < userInput; x++) {
                for (let y = 1; y < userInput; y++) {
                    product = x * y;
                    prodToStr = product.toString();

                    if (prodToStr === prodToStr.split("").reverse().join("")) {
                        if (largestPal < product) {
                            largestPal = product;
                        }
                    }
                }
            }
            return largestPal;
        }

        function confirmPalindrome() {
            Swal.fire({
                title: 'CAUTION',
                text: "DO YOU WANT TO CONTINUE?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No',
                didOpen: () => {
                    const popup = document.querySelector('.swal2-popup');
                    const title = document.querySelector('.swal2-title');
                    const text = document.querySelector('.swal2-text');


                    popup.style.backgroundColor = '#850101';
                    title.style.backgroundColor = '#ffffff';
                    title.style.color = '#050203';
                    text.style.color = '#ffffff';
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        title: 'Calculating...',
                        allowOutsideClick: false,
                        onBeforeOpen: () => {
                            storeInput(document.getElementById('three-digit').value);
                            Swal.showLoading();
                        }
                        
                        
                       
                    });
                    setTimeout(() => {
                        largestPalindrome();
                        Swal.fire({
                            title: 'Result',
                            text: 'The largest palindrome is: ' + largestPalindrome(),
                            icon: 'success'
                        });
                    }, 1000); // Adding a delay to simulate calculation time, adjust as needed
                }
            });
        }

